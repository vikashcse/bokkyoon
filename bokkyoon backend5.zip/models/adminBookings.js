const { Schema, model } = require("mongoose");

const adminBookings = new Schema(
  {
    booking_id:{type:String},
    user_name:{
      type: String,
    },
    user_phone:{type:String},
    source: {
      type: String,
    },
    destination:{
        type:String,
    },
    fare:{
      type:Number,
    },
    Vehicle_type:{
      type:String,
    },
    Vehicle_Registration_Number:{
      type:String,
    },
    bookingid:{
      type:String,
    },
    driver_name: {
      type: String,
    },
    driver_image:{
      type:String,
    },
    driver_phone:{
      type:String,
    },
    Vehicle_Registration_Number:{
      type:String,
    },
    date:{
      type: Date, required: true, default: Date.now()
    },
    status:{type:String,default:1},
  }
);

module.exports = model("adminBookings", adminBookings);
