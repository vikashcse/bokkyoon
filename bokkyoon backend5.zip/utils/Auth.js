const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const passport = require("passport");
const User = require("../models/User");
const Driver=require("../models/Driver")
const Bookings = require("../models/Bookings")
const { SECRET } = require("../config");
const notification = require('../models/notification');
const vehicles = require("../models/vehicles");


/**
 * @DESC To register the user (ADMIN, SUPER_ADMIN, USER)
 */
const userRegister = async (userDets, role, res,photo) => {
  try {
    // validate the email
    let emailNotRegistered = await validateEmail(userDets.phone);
    if (!emailNotRegistered) {
      return res.status(200).json({
        message: `Phone is already registered.`,
        success: false
      });
    }

    // Get the hashed password

    // create a new user
    const newUser = new User({
      ...userDets,
      role,
      profile_pic:photo
    });

    await newUser.save((err,docs)=>{
      if(!err){
        res.json({
          message:"Registration Successfull.",
          success:true,
          name:docs.name,
          phone:docs.phone,
          email:docs.email
        })
      }
      else{res.send(err)}
    });

  } catch (err) {
    // Implement logger function (winston)
    return res.status(200).json({
      message: `Unable to create your account. ${err}`,
      success: false
    });
  }
};

/**
 * @DESC To Login the user (ADMIN, SUPER_ADMIN, USER)
 */
const userLogin = async (userCreds, role, res) => {
  let { phone, password } = userCreds;
  // First Check if the username is in the database
  const user = await User.findOne({ phone });
  if (!user) {
    return res.status(200).json({
      message: "Phone is not found. Invalid login credentials.",
      success: false
    });
  }
  // We will check the role
  if (user.role !== role) {
    return res.status(200).json({
      message: "Please make sure you are logging in from the right portal.",
      success: false
    });
  }

  if (password== user.password) {
    // Sign in the token and issue it to the user
    let token = jwt.sign(
      {
        user_id: user._id,
        role: user.role,
        name:user.name,
        phone:phone,
        email: user.email
      },
      SECRET,
      { expiresIn: "7 days" }
    );

    let result = {
      role: user.role,
      email: user.email,
      name:user.name,
      phone:user.phone,
      token: `Bearer ${token}`,
      expiresIn: 168
    };

    return res.status(200).json({
      ...result,
      message: "Hurray! You are now logged in.",
      success: true
    });
  } else {
    return res.status(200).json({
      message: "Incorrect password.",
      success: false
    });
  }
};

const validateUsername = async username => {
  let user = await User.findOne({ username });
  return user ? false : true;
};

/**
 * @DESC Passport middleware
 */
const userAuth = passport.authenticate("jwt", { session: false });

/**
 * @DESC Check Role Middleware
 */
const checkRole = roles => (req, res, next) =>
  !roles.includes(req.user.role)
    ? res.status(401).json("Unauthorized")
    : next();

const validateEmail = async phone => {
  let user = await User.findOne({ phone });
  return user ? false : true;
};

const serializeUser = user => {
  return {
    phone: user.phone,
    email: user.email,
    name: user.name,
    _id: user._id,
    updatedAt: user.updatedAt,
    createdAt: user.createdAt
  };
};

const getUser=(res)=>{
  User.find((err,docs)=>{
    if(!err){
      res.send(docs)
    }
    else{
      res.json(
        {
          message: `Error:- ${err}`,
          success:false
        }
      )
    }
  })
}

const deleteUser=(req,res)=>{
  if(req.body.admin_password=="@B0ky00n#"){
    User.findByIdAndDelete({_id:req.body.id},(err)=>{
      if(!err){
        res.json(
          {
            message: `Delete Successfull.`,
            success:true
          }
        )
      }
    })
  }
  else{
    res.json(
      {
        message: `You Are Not Authorized.`,
        success:false
      }
    )
  }
}


const validateDriverEmail = async phone => {
  let driver = await Driver.findOne({ phone });
  return driver ? false : true;
};

const driverRegister=async(req,res,profile_pic)=>{
  console.log("dr")
  try {
    // validate the email
    let emailNotRegistered = await validateDriverEmail(req.body.phone);
    if (!emailNotRegistered) {
      return res.status(200).json({
        message: `Phone Number is already registered.`,
        success: false
      });
    }

    // Get the hashed password
    //const password = await bcrypt.hash(req.body.password, 12);
    // create a new user
    const newUser = new Driver({
      ...req.body,
      //password,
      profile_pic:profile_pic,
      Vehicle_Type:req.body.Vhicle_Type
    });

    await newUser.save();
    return res.status(201).json({
      message: "Hurry! now you are successfully registred. Please login.",
      success: true
    });
  } catch (err) {
    // Implement logger function (winston)
    return res.status(400).json({
      message: "Unable to create your account.",
      success: false
    });
  }
}

const getDriver=(res)=>{
  Driver.find((err,docs)=>{
    if(!err){
      res.send(docs)
    }
    else{
      res.json(
        {
          message: `Error:- ${err}`,
          success:false
        }
      )
    }
  })
}

const deleteDriver=(req,res)=>{
  Driver.findByIdAndDelete({_id:req.body._id},(err)=>{
    if(!err){
      res.json(
        {
          message: `Delete Successfull.`,
          success:true
        }
      )
    }
    else{
      res.json(
        {
          message: `Error:- ${err}`,
          success:false
        }
      )
    }
  })
}


const checkOldPassword = async (req) => {
  let cop = await User.findOne({phone:req.body.phone});
  let isMatch = req.body.oldpassword==cop.password;
  return isMatch;
};

const changePassword= async (req,res)=>{
  if(await checkOldPassword(req)){
    User.findOneAndUpdate({phone:req.body.phone},{password:req.body.password,},(err,docs)=>{
      if(!err){
        res.json(
          {
            message: `Successfully Changed`,
            success:true
          }
        )
      }
      else{
        res.json(
          {
            message: `User Does not exist`,
            success:false
          }
        )
      }
    })
  }
  else{
    res.json(
      {
        message: `Old Password Does Not.`,
        success:false
      })
  }

}

const forgotPassword=(req,res)=>{
  console.log(req.body.phone)
  User.find({phone:req.body.phone},(err,docs)=>{
    if(docs.length==0){
      res.json(
        {
          message: `User Does not Exits`,
          success:true
        }
      )
    }
    else if(docs.length>0){
      res.json(
        {
          message: `User Exits`,
          success:true
        }
      )
    }
    else{
      res.json(
        {
          message: `Error:- ${err}`,
          success:false
        }
      )
    }
  })
}

const showNearByCars=(req,res)=>{
  vehicles.find({source:req.body.location},(err,docs)=>{
    if(docs.length==0){
      res.json({
        message:"No Cars In Your Location.",
        success:false
      })
    }
    else if(docs.length>0){
      res.json({
        message:"Near By Cars",
        success:true,
        data:docs
      })
    }
    else{
      res.json({
        message:"Please Try Again Later.",
        success:false
      })
    }
  })
  //username mobile pickupLocation dropLocation
  //res object>data array> Vehicle_Image ,vechile name , vechile number,driver image name phone and rent
}

const book= async(req,res)=>{
  Bookings.find({phone:req.body.phone},(err,docs)=>{
    if(!err){
      console.log(docs)
    }
  })
}


const notifications = (req, res) => {
  notification.find({ phone: req.body.phone }, (err, docs) => {
    if (docs.length == 0) {
      const not = new notification({
        phone: req.body.phone,
        notification: [{ msg: req.body.notification, title: req.body.title }]
      })
      not.save((err, docs) => {
        if (!err) {
          res.json({
            message: "Notification is Send.",
            success: true,
          })
        }
        else {
          res.json({
            message: "Notification not Send.",
            success: false,
          })
        }
      })
    }
    else if (docs.length > 0) {
      updateNotification(req, res)
    }
    else {
      res.json({
        message: "No Notifications",
        success: false,
      })
    }
  })
}

const updateNotification = (req, res) => {
  notification.findOneAndUpdate(
    { phone: req.body.phone },
    {
      $push: {
        notification: [{ msg: req.body.notification, title: req.body.title }]
      }
    },
    (err, docs) => {
      if (!err) {
        res.json({
          message: "Notification is Send.",
          success: true,
        })
      }
      else {
        res.json({
          message: "Notification not Send.",
          success: false,
        })
      }
    }

  )
}

const getUserNotification = async (req, res) => {
  notification.find({ phone: req.body.phone }, (err, docs) => {
    if (docs.length == 0) {
      res.json({
        message: "Notification not Found.",
        success: false,
      })
    }
    else if (docs.length > 0) {
      res.json({
        message: "User Notifications.",
        success: true,
        data: docs[0]
      })
    }
    else {
      res.json({
        message: "Notification not Found.",
        success: false,
      })
    }
  })
}



module.exports = {
  userAuth,
  checkRole,
  userLogin,
  userRegister,
  serializeUser,
  getUser,
  deleteUser,
  driverRegister,
  getDriver,
  deleteDriver,
  forgotPassword,
  changePassword,
  showNearByCars,
  book,
  notifications,
  getUserNotification
};
