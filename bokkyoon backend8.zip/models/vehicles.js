const { Schema, model } = require("mongoose");

const vehicles = new Schema(
  {
    source:{
      type:String
    },
    radious:{
      type: Number,
    },
    driver_name: {
      type: String,
    },
    fare:{
      type:Number,
    }
  }
);

module.exports = model("vehicles", vehicles);
