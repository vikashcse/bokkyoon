const { Schema, model } = require("mongoose");

const Bookings = new Schema(
  {
    phone:{
      type: Number,
      required: true
    },
    email: {
      type: String,
    },
    name: {
      type: String,
    },
    bookings:[{
      vehicle_name:{type:String,require:true},
      Vehicle_Registration_Number:{type:String,require:true},
      Vehicle_Image:{type:String,require:true},
      source:{type:String},
      destination:{type:String},
      fare:{type:String},
      date:{type: Date, required: true, default: Date.now()}
    }]
  },
  { timestamps: true }
);

module.exports = model("Bookings", Bookings);
