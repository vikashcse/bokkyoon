const { Schema, model } = require("mongoose");

const carType  = new Schema(
  {
    type:{
      type:String
    },
    farePerKm:{
      type: Number,
      required: true
    }
  }
);

module.exports = model("carType", carType);
