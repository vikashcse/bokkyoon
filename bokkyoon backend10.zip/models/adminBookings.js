const { Schema, model } = require("mongoose");

const adminBookings = new Schema(
  {
    userName:{
      type: String,
    },
    userPhone:{type:String},
    driverName: {
      type: String,
    },
    source: {
      type: String,
    },
    destination:{
        type:String,
    },
    fair:{
      type:Number,
    },
    Vehicle_Registration_Number:{
      type:String,
    },
    bookingid:{
      type:String,
    },
    status:{type:String,default:"pending", enum: ["pending", "copleted", "cancled"]}
  }
);

module.exports = model("adminBookings", adminBookings);
