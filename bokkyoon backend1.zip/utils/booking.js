const TrustedComms = require('twilio/lib/rest/preview/TrustedComms')
const Bookings = require('../models/Bookings')


//Check if User Booking List exists
const checkBookings = async (req, res) => {
    const checkForExistance = await Bookings.findOne({ phone: req.body.phone })
    return checkForExistance ? false : true
}

//function call
const booking = async (req, res) => {
    console.log(await checkBookings(req, res))
    //addToExistingBookingLIst(req, res)
    if(!await checkBookings(req,res)){
        console.log("exist")
        //createNewBooking(req,res)
        await addToExistingBookingLIst(req,res)

    }
    else if(await checkBookings(req,res)) {
        console.log("not exist")
        await createNewBooking(req,res)
        //addToExistingBookingLIst(req,res)
    }

}

//create New Booking
const createNewBooking = (req, res) => {
    const newBooking = new Bookings({
        phone: req.body.phone,
        bookings: { ...req.body }
    })
    newBooking.save((err, docs) => {
        if (!err) {
            res.json({
                message: "Booking Succrssful",
                success: true
            })
        }
    })
}

//add to existing booking list
const addToExistingBookingLIst = (req, res) => {
    Bookings.findOneAndUpdate({ phone: req.body.phone },
        {
            $push: {
                bookings: { ...req.body }
            }
        }, (err, docs) => {
            if (!err) {
                res.json({
                    message: "Booking Succrssful",
                    success: true
                })
            }
            else {
                res.json({
                    message: "Not able to book",
                    success: false
                })
            }
        })
}



module.exports = {
    booking
};