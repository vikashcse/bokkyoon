const TrustedComms = require('twilio/lib/rest/preview/TrustedComms')
const Bookings = require('../models/Bookings')
const adminBookings = require('../models/adminBookings')

//Check if User Booking List exists
const checkBookings = async (req, res) => {
    const checkForExistance = await Bookings.findOne({ phone: req.body.phone })
    return checkForExistance ? 1 : 2
}

const getBookingLength = async (phone) => {
    const bookinglength = await Bookings.findOne({ user_phone: phone })
    return bookinglength.bookings.length
}

const bookingLength = async (phone) => {
    console.log("bookingLength")
    console.log(await getBookingLength(phone))
    var lengt
    var id
    const docs = await Bookings.findOne({ user_phone: phone })
    length = docs.bookings.length - 1
    id = docs.bookings[length]._id
    return [length, id]
}

//add to admin
const addToAdmin = async (req, res) => {
    console.log("addToAdmin")
    // currentBooking = await bookingLength(req.body.user_phone)
    // console.log(currentBooking)
    await Bookings.findOne({ user_phone: req.body.user_phone }, (err, docs) => {
        console.log(docs.bookings.length)
        var length=docs.bookings.length
        const newBooking = new adminBookings({
            ...req.body,
            booking_id: docs.bookings[length-1]._id
        })
        newBooking.save((err, data) => {
            if (!err) {

            }
            else {
                res.json({
                    message: err,
                    success: false
                })
            }
        })
    })


    // const newBooking = new adminBookings({
    //     ...req.body,
    //     booking_id: currentBooking[1]
    // })
    // await newBooking.save((err, data) => {
    //     if (!err) {

    //     }
    //     else {
    //         res.json({
    //             message: err,
    //             success: false
    //         })
    //     }
    // })
}



//create New Booking
const createNewBooking = async (req, res) => {
    console.log("createNewBooking")
    var ifNoError = false
    const newBooking = new Bookings({
        user_phone: req.body.user_phone,
        bookings: { ...req.body }
    })
    await newBooking.save(async (err, docs) => {
        if (!err) {
            res.json({
                message: "Booking Succrssful",
                success: true
            })
            await addToAdmin(req, res)
        }
    })


}

//add to existing booking list
const addToExistingBookingLIst = async (req, res) => {
    var ifNoError = false
    console.log("addToExistingBookingLIst")
    Bookings.findOneAndUpdate({ user_phone: req.body.user_phone },
        {
            $push: {
                bookings: { ...req.body }
            }
        }, async (err, docs) => {
            if (!err) {
                res.json({
                    message: "Booking Succrssful",
                    success: true
                })
                // console.log(docs.bookings.length)
                // console.log(docs.bookings)
                // res.send(docs.bookings[docs.bookings.length-1])
                await addToAdmin(req, res)


            }
            else {
                res.json({
                    message: "Not able to book",
                    success: false
                })
            }
        })

}


//function call
const booking = async (req, res) => {

    if (await checkBookings(req, res) == 1) {
        addToExistingBookingLIst(req, res)
    }
    else if (await checkBookings(req, res) == 2) {
        createNewBooking(req, res)
    }
}

module.exports = {
    booking
};