const { Schema, model } = require("mongoose");

const notification = new Schema(
  {
    phone: {
      type: String,
      required: true
    },
    notification:[]
  },
  { timestamps: true }
);

module.exports = model("notification", notification);