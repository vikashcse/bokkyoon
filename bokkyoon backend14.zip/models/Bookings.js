const { Schema, model } = require("mongoose");

const Bookings = new Schema(
  {
    user_phone:{
      type: Number,
      required: true
    },
    email: {
      type: String,
    },
    user_name: {
      type: String,
    },
    bookings:[{
      driver_name:{type:String},
      driver_image:{type:String},
      driver_phone:{type:Number},
      vehicle_name:{type:String},
      Vehicle_Registration_Number:{type:String},
      Vehicle_Image:{type:String},
      Vehicle_type:{type:String},
      source:{type:String},
      destination:{type:String},
      fare:{type:String},
      date:{type: Date, required: true, default: Date.now()},
      status:{type:Number,require:true,default:1}
      
    }]
  },
  { timestamps: true }
);

module.exports = model("Bookings", Bookings);
