const { Schema, model } = require("mongoose");

const userRides = new Schema(
  {
    phone: {
      type: String,
    },
    myrides:[]
  }
);

module.exports = model("userRides", userRides);
