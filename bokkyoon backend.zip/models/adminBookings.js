const { Schema, model } = require("mongoose");

const adminBookings = new Schema(
  {
    booking_id:{type:String},
    user_name:{
      type: String,
    },
    user_phone:{type:String},
    source: {
      type: String,
      default: ''
    },
    destination:{
        type:String,
        default: ''
    },
    fare:{
      type:Number,
      default: 0
    },
    Vehicle_type:{
      type:String,
      default: ''
    },
    driver_name: {
      type: String,
      default: ''
    },
    driver_image:{
      type:String,
      default: ''
    },
    driver_phone:{
      type:String,
      default: ''
    },
    Vehicle_Registration_Number:{
      type:String,
      default: ''
    },
    vehicle_name:{type:String,default: ''},
    date:{
      type: Date, required: true, default: Date.now()
    },
    status:{type:String,default:1},
  }
);

module.exports = model("adminBookings", adminBookings);
