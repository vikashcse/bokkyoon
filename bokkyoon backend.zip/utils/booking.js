const TrustedComms = require('twilio/lib/rest/preview/TrustedComms')
const Bookings = require('../models/Bookings')
const adminBookings = require('../models/adminBookings')

//Check if User Booking List exists
const checkBookings = async (req, res) => {
    const checkForExistance = await Bookings.findOne({ phone: req.body.phone })
    return checkForExistance ? 1 : 2
}

const bookingLength = async (phone) => {
    var length
    var id
    console.log(phone)
    await Bookings.findOne({ user_phone: phone }, (err, docs) => {
        if (docs) {
            length = docs.bookings.length
            id = docs.bookings[docs.bookings.length - 1]._id
        }
        else {
            data = 0
        }
    })
    return [length, id]
}

//add to admin
const addToAdmin = async (req, res) => {
    currentBooking = await bookingLength(req.body.user_phone)
    console.log(currentBooking)


    const newBooking = new adminBookings({
        ...req.body,
        booking_id: currentBooking[1]
    })
    newBooking.save((err, data) => {
        if (!err) {
            res.json({
                message: "Booking Succrssful",
                success: true
            })
        }
        else {
            res.json({
                message: err,
                success: false
            })
        }
    })
}



//create New Booking
const createNewBooking = async (req, res) => {
    const newBooking = new Bookings({
        user_phone: req.body.user_phone,
        bookings: { ...req.body }
    })
    await newBooking.save((err, docs) => {
        if (!err) {
            // console.log(docs.bookings.length)
            // console.log(docs.bookings)
            // res.send(docs.bookings[docs.bookings.length-1])
            addToAdmin(req, res)

        }
    })
}

//add to existing booking list
const addToExistingBookingLIst = async (req, res) => {

    Bookings.findOneAndUpdate({ user_phone: req.body.user_phone },
        {
            $push: {
                bookings: { ...req.body }
            }
        }, (err, docs) => {
            if (!err) {
                // console.log(docs.bookings.length)
                // console.log(docs.bookings)
                // res.send(docs.bookings[docs.bookings.length-1])
                addToAdmin(req, res)

            }
            else {
                res.json({
                    message: "Not able to book",
                    success: false
                })
            }
        })
}


//function call
const booking = async (req, res) => {

    if (await checkBookings(req, res) == 1) {
        console.log("exist")
        console.log(await checkBookings(req, res))
        await addToExistingBookingLIst(req, res)
    }
    else if (await checkBookings(req, res) == 2) {
        console.log("not exist")
        console.log(await checkBookings(req, res))
        await createNewBooking(req, res)
    }
}

module.exports = {
    booking
};