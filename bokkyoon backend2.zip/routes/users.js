const router = require("express").Router();
const multer = require('multer');
const Bookings = require("../models/Bookings");
const userRides = require("../models/UserRides")
const driver = require("../models/Driver")
const { v4: uuidv4 } = require('uuid');
const fs = require("fs");
const User = require("../models/User");
const faq = require('../models/faq')
const token = require('../models/notificationToken')
const vehicles = require('../models/vehicles')
const adminBookings = require('../models/adminBookings')
const admin = require('../models/admin')
const carType = require('../models/typeofcar')
const bcrypt = require("bcryptjs");
var twilio = require('twilio');
var client = new twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
const winston = require('winston');
const fetch = require('node-fetch')

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  defaultMeta: { service: 'user-service' },
  transports: [
    new winston.transports.Console("xxxxxxxxxxx"),


    // - Write all logs with level `error` and below to `error.log`
    // - Write all logs with level `info` and below to `combined.log`
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' }),
  ],
});

const today = new Date();

//storage startegy
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
});
//file filter
const fileFilter = (req, file, cb) => {
  //reject file
  if (file.mimetype === 'image/jpg' || file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
    cb(null, true);
  }
  else {
    cb(new Error('Message wrong file type.'), false);
  }
}

const upload = multer({
  storage: storage,
  fileFilter: fileFilter
});
// Bring in the User Registration function
const {
  userAuth,
  userLogin,
  checkRole,
  userRegister,
  serializeUser,
  getUser,
  deleteUser,
  driverRegister,
  getDriver,
  deleteDriver,
  changePassword,
  forgotPassword,
  showNearByCars,
  book,
  notifications,
  getUserNotification

} = require("../utils/Auth");

const {
  addUserFromDashboard
} = require("../utils/Dashboard")
const { booking } = require('../utils/booking')
// Users Registeration Route
router.post("/register-user", async (req, res) => {
  console.log("register  " + req.body)
  await userRegister(req.body, "user", res);
});

router.post('/deletUser', (req, res) => {
  User.findByIdAndDelete({ _id: req.body._id }, (err, docs) => {
    if (!err) {
      res.send({
        message: "Deleted",
        success: true
      })
    }
  })
})
//deletUser
router.post("/register-driver", upload.single("profile_pic"), async (req, res) => {
  console.log(req.file)
  profile_pic = String(req.protocol + "://" + req.hostname + ":" + process.env.APP_PORT + "/" + req.file.destination + req.file.originalname)
  await driverRegister(req, res, profile_pic);
});

// Admin Registration Route
router.post("/register-admin", async (req, res) => {
  await userRegister(req.body, "admin", res);
});

// Super Admin Registration Route
router.post("/register-super-admin", async (req, res) => {
  await userRegister(req.body, "superadmin", res);
});

// Users Login Route
router.post("/login-user", async (req, res) => {
  await userLogin(req.body, "user", res);
});

// Admin Login Route
router.post("/login-admin", async (req, res) => {
  await userLogin(req.body, "admin", res);
});

// Super Admin Login Route
router.post("/login-super-admin", async (req, res) => {
  await userLogin(req.body, "superadmin", res);
});

// Profile Route
router.get("/profile", userAuth, async (req, res) => {
  return res.json(serializeUser(req.user));
});

router.post('/forgotPassword', (req, res) => {
  //mo no exist
  //new pass
  forgotPassword(req, res)
})

router.post('/changePassword', (req, res) => {
  //mo no exist
  //new pass
  changePassword(req, res)
})

// Users Protected Route
router.get(
  "/user-protectd",
  userAuth,
  checkRole(["user"]),
  async (req, res) => {
    return res.json("Hello User");
  }
);

// Admin Protected Route
router.get(
  "/admin-protectd",
  userAuth,
  checkRole(["admin"]),
  async (req, res) => {
    return res.json("Hello Admin");
  }
);

// Super Admin Protected Route
router.get(
  "/super-admin-protectd",
  userAuth,
  checkRole(["superadmin"]),
  async (req, res) => {
    return res.json("Hello Super Admin");
  }
);

// Super Admin Protected Route
router.get(
  "/super-admin-and-admin-protectd",
  userAuth,
  checkRole(["superadmin", "admin"]),
  async (req, res) => {
    return res.json("Super admin and Admin");
  }
);

router.get('/getUser', async (req, res) => {
  await getUser(res)
})
router.post('/deleteUser', async (req, res) => {
  await deleteUser(req, res)
})

router.get('/getDriver', async (req, res) => {
  await getDriver(res)
})
router.post('/deletDriver', async (req, res) => {
  await deleteDriver(req, res)
})

router.post('/showNearByCars', async (req, res) => {
  await showNearByCars(req, res)
})

router.post('/book', async (req, res) => {
  await book(req, res)
})

router.get('/getDriver', (req, res) => {
  driver.find((err, docs) => {
    if (docs.length > 0) {
      res.json({
        message: "All Drivers",
        success: true,
        data: docs
      })
    }
    else {
      res.json({
        message: "No Drivers.",
        success: false
      })
    }
  })
})
const addToAdminBookings = (data) => {
  console.log(data['phone'], data['myrides'][0].driverName, data['myrides'][0].destination)

  User.find({ phone: data['phone'] }, (err, docs) => {
    if (docs.length > 0) {
      console.log(docs)
      const newadminBooking = new adminBookings({
        userName: docs[0].name,
        userPhone: docs[0].phone,
        driverName: data['myrides'][0].driverName,
        source: data['myrides'][0].source,
        destination: data['myrides'][0].destination,
        fair: data['myrides'][0].fair,
        bookingid: data['myrides'][0].bookingid,
        Vehicle_Registration_Number: data['myrides'][0].Vehicle_Registration_Number,

      })
      newadminBooking.save()
    }
    else {
      res.send("no user")
    }
  })

}
router.post('/addMyRides', async (req, res) => {
  var driverDetail;
  await driver.find({ _id: req.body.driverId }, (err, docs) => {
    driverDetail = docs[0]
  })

  //console.log(driverDetail)
  newRideBooking = {
    phone: req.body.phone,
    myrides: [{
      driverName: driverDetail.name,
      phone: driverDetail.phone,
      vehicle_name: driverDetail.vehicle_name,
      Vehicle_Registration_Number: driverDetail.Vehicle_Registration_Number,
      profile_pic: driverDetail.profile_pic,
      driverlocation: driverDetail.location,
      source: req.body.source,
      destination: req.body.destination,
      fair: 400,
      date: today.toDateString(),
      bookingid: uuidv4(),
      status: "1"
    }]
  }

  addToAdminBookings(newRideBooking)
  userRides.find({ phone: req.body.phone }, (err, docs) => {
    if (docs.length == 0) {
      createNewRides(req, res, newRideBooking)
    }
    else if (docs.length > 0) {
      addToExistingBooking(req, res, newRideBooking)
    }
    else {
      res.json({
        message: err,
        success: true
      })
    }

  })
})

const createNewRides = async (req, res, data) => {
  const newRide = new userRides(data)

  await newRide.save((err, docs) => {
    if (!err) {
      res.json({
        message: "Booking Successfull.",
        success: true,
        data: data.myrides[0]
      })
    }
    else {
      res.json({
        message: "Please Try Again.",
        success: false
      })
    }
  })
}


const addToExistingBooking = async (req, res, data) => {
  await userRides.findOneAndUpdate({ phone: req.body.phone }, {
    $push: {
      myrides: [...data.myrides]
    }
  }, (err, docs) => {
    if (!err) {
      res.json({
        message: "Booking Successfull.",
        success: true,
        data: data.myrides[0]
      })
    }
    else {
      res.json({
        message: "Please Try Again.",
        success: false
      })
    }
  })
}

router.post('/getMyRides', async (req, res) => {
  await Bookings.findOne({ user_phone: req.body.user_phone }, (err, docs) => {
    if (docs) {
      res.json({
        message: "My Rides.",
        success: true,
        data: docs.bookings
      })
    }
    else if (!docs) {
      res.json({
        message: "No Rides.",
        success: false
      })
    }
    else {
      res.json({
        message: "Please Try Again.",
        success: false
      })
    }
  })
})

router.post('/cancelMyRide', async (req, res) => {
  await userRides.updateOne(
    { phone: req.body.phone },
    {
      $set:
      {
        'myrides.$[el].status': "2"
      }
    },
    {
      arrayFilters: [{ "el.bookingid": req.body.bookingid }],
      new: false
    },
    function (err, docs) {
      if (!err) {
        res.json({
          message: "Your Ride Canceled Successfully.",
          success: true
        })
      }
      else {
        res.json({
          message: "Try Again Later.",
          success: false
        })
      }
    }
  );
})


router.post('/updateProfile', upload.single("vikash"), (req, res) => {
  //console.log(req.file)
  //profile_pic=String(req.protocol+"://"+req.hostname+":3000/"+req.file.destination+req.body.phone+".jpg")
  console.log(req.body.email, req.body.name, req.body.phone)
  fs.writeFile(`uploads/${req.body.phone}.jpg`, new Buffer.from(req.body.profile_pic, "base64"), function (err) { });
  profile_pic = String(req.protocol + "://" + req.hostname + ":" + process.env.APP_PORT + "/" + `uploads/${req.body.phone}.jpg`)
  User.findOneAndUpdate({ phone: req.body.phone }, { profile_pic: profile_pic, name: req.body.name, email: req.body.email }, (err, docs) => {
    if (!err) {
      res.send(docs)
    }
    else {
      res.status(201).json({
        message: `Error:- ${err}`,
        success: false,
      });
    }
  })
})

router.post('/notification', async (req, res) => {
  await notifications(req, res)
})

router.post('/getUserNotification', async (req, res) => {
  await getUserNotification(req, res)
})

router.post('/addfaq', (req, res) => {
  const fa = new faq({
    question: req.body.question,
    answer: req.body.answer
  })
  fa.save((err, docs) => {
    if (!err) {
      res.send("Faq Added")
    }
    else {
      res.send(err)
    }
  })
})

router.get('/getfaq', (req, res) => {
  faq.find((err, docs) => {
    if (!err) {
      res.send(docs)
    }
    else {
      res.send(err)
    }
  })
})

router.post('/resetPassword', async (req, res) => {
  User.findOneAndUpdate({ phone: req.body.phone }, { password: req.body.password }, (err, docs) => {
    if (!err) {
      res.json({
        message: "New Password Set",
        success: true
      })
    }
    else {
      res.json({
        message: "Try Again Later",
        success: false
      })
    }
  })
})

router.post('/updateToken', (req, res) => {
  token.find({ phone: req.body.phone }, (err, docs) => {
    if (docs.length == 0) {
      const newToken = new token({
        phone: req.body.phone,
        token: req.body.token
      })

      newToken.save((err, docs) => {
        if (!err) {
          res.json({
            messageL: "Token Saved",
            success: true
          })
        }
        else {
          res.json({
            messageL: err,
            success: false
          })
        }
      })
    }
    else if (docs.length > 0) {
      token.findOneAndUpdate({ phone: req.body.phone }, { token: req.body.token }, (err, obj) => {
        if (!err) {
          res.json({
            messageL: "New Tokrn Saved",
            success: true
          })
        }
        else {
          res.json({
            messageL: err,
            success: false
          })
        }
      })

    }
    else {

    }
  })
})


router.post('/deletUserDetail', async (req, res) => {
  if (req.body.admin_password == "@B0ky00n#") {
    await User.findOneAndDelete({ phone: req.body.phone }, (err, docs) => {
      if (docs) {
        logger.log({
          level: 'info',
          message: `Deleted User ${docs}`
        });
      }
      else {
        logger.log({
          level: 'info',
          message: `Error :- ${err}`
        });
      }
    })

    await userRides.findOneAndDelete({ phone: req.body.phone }, (err, docs) => {

    })

    res.send("Delete Successfull.")
  }
})

router.post('/createAdmin', (req, res) => {
  const newAdmin = new admin({
    email: req.body.email,
    name: req.body.name,
    password: req.body.password
  })

  newAdmin.save((err, docs) => {
    if (!err) {
      res.json({
        message: "Created",
        success: true
      })
    }
    else {
      res.json({
        message: `Error:- ${err}`,
        success: false
      })
    }
  })
})

router.post('/Admin', (req, res) => {
  console.log(req.body)
  admin.findOne({ email: req.body.email }, (err, docs) => {
    if (docs) {
      if (docs.password == req.body.password) {
        res.json({
          message: `Welcome Admin`,
          success: true
        })
      }
      if (docs.password != req.body.password) {
        res.json({
          message: `Wrong Password`,
          success: false
        })
      }
    }
    else if (!docs) {
      res.json({
        message: `No Admin`,
        success: false
      })
    }
    else {
      if (docs) {
        res.json({
          message: `Error :- ${err}`,
          success: false
        })
      }
    }
  })
})

router.post('/vehicles', (req, res) => {
  console.log(req.body)
  var driverdata;
  driver.find({ _id: req.body.selectedDriver }, (err, docs) => {
    if (!err) {
      driverdata = docs[0];
      const newVehicles = new vehicles({
        source: req.body.source,
        radious: req.body.radious,
        driver_name: driverdata.name,
        fare: req.body.fairAmount
      })

      newVehicles.save((err, docs) => {
        res.json({
          message: `All Vehicles.`,
          success: true,
          data: docs
        })
      })
    }
  })


})


router.get('/getAllVehicles', (req, res) => {
  vehicles.find((err, docs) => {
    if (docs.length > 0) {
      res.json({
        message: "All Vehicles,",
        success: true,
        data: docs
      })
    }
    else if (docs.length == 0) {
      res.json({
        message: "No Vehicles,",
        success: false
      })
    }
    else {
      res.json({
        message: `Error:- ${err}`,
        success: false
      })
    }
  })
})

router.get('/adminBookings', (rq, res) => {
  adminBookings.find((err, docs) => {
    if (docs.length > 0) {
      res.send(docs)
    }
    else {
      res.send(err)
    }
  })
})
router.post('/getUserToUpdate', (req, res) => {

  User.findById({ _id: req.body._id }, (err, docs) => {
    if (!err) {
      res.send(docs)
    }
  })
})

router.post('/updateUserDashboard', upload.single("profile_pic"), (req, res) => {
  profile_pic = String(req.protocol + "://" + req.hostname + ":" + process.env.APP_PORT + "/" + req.file.destination + req.file.originalname)
  console.log(profile_pic)
  console.log(req.body['id'], req.body['name'], req.body['phone'], req.body['email'])
  User.findByIdAndUpdate({ _id: req.body['id'] }, {
    name: req.body['name'],
    phone: req.body['phone'],
    email: req.body['email'],
    password: req.body['password'],
    profile_pic: profile_pic
  }, (err, docs) => {
    if (!err) {
      res.json({
        message: "Update Successfull.",
        success: true
      })
    }
  })
})

router.post('/getDriverToUpdate', (req, res) => {

  driver.findById({ _id: req.body._id }, (err, docs) => {
    if (!err) {
      res.send(docs)
    }
  })
})

router.post('/updateDriverDashboard', upload.single("profile_pic"), (req, res) => {
  profile_pic = String(req.protocol + "://" + req.hostname + ":" + process.env.APP_PORT + "/" + req.file.destination + req.file.originalname)
  console.log(req.body['id'], req.body['name'], req.body['phone'], req.body['Vehicle_Registration_Number'], req.body['Vhicle_Type'], profile_pic)
  driver.findByIdAndUpdate({ _id: req.body['id'] }, {
    name: req.body['name'],
    phone: req.body['phone'],
    vehicle_name: req.body['vehicle_name'],
    Vehicle_Registration_Number: req.body['Vehicle_Registration_Number'],
    Vehicle_Type: req.body['Vhicle_Type'],
    profile_pic: profile_pic
  }, (err, docs) => {
    if (!err) {
      res.json({
        message: "Update Successfull.",
        success: true
      })
    }
  })
})


router.get('/numbers', async (req, res) => {
  var userr;
  var driverr;
  var bookingss;
  await User.find((err, docs) => {

    if (!err) {
      userr = docs.length
    }
    else {
      userr = 0
    }

  })

  await driver.find((err, docs) => {
    if (!err) {
      driverr = docs.length
    }
    else {
      driverr = 0
    }
  })

  await Bookings.find((err, docs) => {
    if (!err) {
      bookingss = docs.length
    }
    else {
      bookingss = 0
    }
  })

  res.json({
    user: userr,
    driver: driverr,
    booking: bookingss
  })

})

const chechOldPassword = (data) => {
  var oldp;
  admin.find({ password: data }, (err, docs) => {
    console.log(docs)
    oldp = docs[0].password
    // if (!err) {
    //   oldp=docs[0].password
    // }
  })
  return oldp
}

router.post("/adminpassword", (req, res) => {
  console.log(req.body.oldpass)
  console.log(chechOldPassword(req.body.oldpass))


})

router.post("/createNewUserFromDashboard", upload.single("profile_pic"), (req, res) => {
  profile_pic = String(req.protocol + "://" + req.hostname + ":4000/" + req.file.destination + req.file.originalname)
  addUserFromDashboard(req, res, profile_pic)
})

router.post('/getVehhicleToUpdate', (req, res) => {
  console.log(req.body)
  vehicles.findById({ _id: req.body._id }, (err, docs) => {
    res.send(docs)
    console.log(docs)
  })
})

router.post('/updateVehicle', (req, res) => {
  console.log(req.body.source)
  vehicles.findByIdAndUpdate({ _id: req.body._id },
    { source: req.body.source, radious: req.body.radious, driver_name: req.body.selectedDriver, fare: req.body.fairAmount }, (err, docs) => {
      if (!err) {
        res.json({
          message: "Succesfully Inserted",
          success: true
        })
      }
      else {
        if (!err) {
          res.json({
            message: `Erroe :- ${err}`,
            success: false
          })
        }
      }
    })
})

router.post('/deleteVehicle', (req, res) => {
  vehicles.findByIdAndDelete({ _id: req.body._id }, (err, docs) => {
    if (!err) {
      res.json({
        message: "Delete Successfull",
        success: true
      })
    }
    else {
      res.json({
        message: `Error:- ${err}`,
        success: false
      })
    }
  })
})

router.post('/adminViewRide', (req, res) => {
  console.log(req.body)
  adminBookings.findById({ _id: req.body._id }, (err, docs) => {
    if (docs) {
      console.log(docs)
      res.send(docs)
    }
  })
})





router.post('/fetchBooking', (req, res) => {
  console.log(req.body)
  adminBookings.findOne({ _id: req.body.id }, (err, docs) => {
    if (docs) {
      res.send(docs)
    }
    else if (!docs) {
      res.send("No Booking")
    }
    else {
      res.json({
        message: `Error:- ${err}`,
        success: false
      })
    }
  })
})

router.post('/getTypesOfCar', (req, res) => {
  carType.find((err, docs) => {
    if (docs.length > 0) {
      res.json({
        message: "All Types",
        success: true,
        data: docs
      })
    }
  })
})

router.post('/createType', (req, res) => {
  const newType = new carType({
    ...req.body
  })
  newType.save((err, docs) => {
    if (!err) {
      res.json({
        message: "New Type Created",
        success: true
      })
    }
  })
})

router.post('/deletType', (req, res) => {
  carType.findByIdAndDelete({ _id: req.body.id }, (err, docs) => {
    if (!err) {
      res.json({
        message: "Delete Successful",
        success: true
      })
    }
    else {
      res.send(err)
    }
  })
})

router.post('/updateVehicleType', (req, res) => {
  carType.findOneAndUpdate({ _id: req.body.id }, { ...req.body }, (err, docs) => {
    if (!err) {
      res.json({
        message: "Booking Modified",
        success: true
      })
    }
    else {
      res.json({
        message: `Error:- ${err}`,
        success: false
      })
    }
  })
})

router.post('/gettypetoupdate', (req, res) => {
  carType.findById({ _id: req.body.id }, (err, docs) => {
    if (!err) {
      res.json({
        data: docs
      })
    }
  })
})

router.post('/mybookings', async (req, res) => {
  await booking(req, res)
})

router.post('/getAllTokens', (req, res) => {
  token.find((err, docs) => {
    res.send(docs)
  })
})


router.post('/getBookingForEdit', async (req, res) => {
  console.log(req.body)
 
  await adminBookings.findOneAndUpdate({ booking_id: req.body.booking_id }, { ...req.body }, (err, docs) => {
    if (!err) {
      res.json({
        message: "Booking Modified",
        success: true
      })
      findToken(req, docs)
      editMyBookings(docs)
      console.log("xxxxxxxxxxxxxxxxxxxxxxxxx")
      console.log(docs)
    }
    else {
      res.json({
        message: `Error:- ${err}`,
        success: false
      })
    }
  })
})

const editMyBookings = async(data) => {
  await Bookings.updateOne(
    { user_phone: "8235188063" },
    {
      $set:
      {
        'bookings.$[el].status': data.status,
        'bookings.$[el].Vehicle_Registration_Number': data.Vehicle_Registration_Number,
        'bookings.$[el].driver_name': data.driver_name,
        'bookings.$[el].driver_phone': data.driver_phone,
        'bookings.$[el].fare': data.fare,
        'bookings.$[el].driver_image': data.driver_image,

      }
    },
    {
      arrayFilters: [{ "el._id": data.booking_id }],
      new: false
    },(err,docs)=>{
      if(!err){}
    })
  // Bookings.findOneAndUpdate({ phone: req.body.user_phone },
  //   {
  //     $set: { 'bookings.$.status': "4" }
  //   })
}

//find Token to send push Notification
const findToken = async (req) => {
  await token.findOne({ phone: req.body.user_phone }, async (err, docs) => {
    if (docs) {
      if (req.body.status == 1) {
        console.log(1)
        sendPushNotification(req, docs.token, "Your Booking is Pending.")
      }
      else if (req.body.status == 2) {
        console.log(2)
        sendPushNotification(req, docs.token, "Thank You !! Hope You Haved Enjoyed Yor Ride.")
      }
      else if (req.body.status == 3) {
        console.log(3)
        sendPushNotification(req, docs.token, "Your Booking Has Been Cancled.")
      }
      else if (req.body.status == 4) {
        console.log(4)
        sendPushNotification(req, docs.token, "Your Booking is Successful.")
      }
    }
  })
}

//send push notification
router.post('/sendUserPushNotification', (req, res) => {
  findToken(req)
})

const sendPushNotification = (req, token, data) => {
  var notification = {
    "title": "Bokkyoon",
    "body": data
  }
  var data = {
    "title": "Bokkyoon",
    "body": data,
    "id": req.body.booking_id
  }
  var fcm_tokens = [token];
  var notification_body = {
    'notification': notification,
    "data": data,
    'registration_ids': fcm_tokens

  }


  fetch('https://fcm.googleapis.com/fcm/send', {
    'method': 'POST',
    'headers': {
      'Authorization': 'key=' + 'AAAASLHAFWk:APA91bFLQyxwAQWeKfyjs15nPy1XTG9MZNoDdYHjgzldS2KX2YoEt4paxDdrKmKv8gX00qsTFxgAs_DNdlO4cliuRxpKhZYiVEL4UHYPi2vJX80rh7R07bif-9RfQkwhVa1A7-785Ksh',
      'Content-Type': 'application/json'
    },
    'body': JSON.stringify(notification_body),
    "data": data
  }).
    then(() => {
      //res.status(200).send('Notification Send')
      console.log("Notification Send")

    }).catch((err) => {
      //res.status(200).send(`Error ${err}`)
      console.log(`Error ${err}`)
    })
}

router.post('/notifyid', (req, res) => {
  adminBookings.findOne({ user_phone: req.body.phone }, (err, docs) => {
    if (docs) {
     // console.log(docs['bookings'].find(data => data._id == req.body.id))

      res.json({
        message: "Booking Details",
        success: true,
        data: docs
      })
    }
    else if (!docs) {
      res.json({
        message: "NO Booking ",
        success: false
      })
    }
    else {
      res.json({
        message: `Error :- ${err}`,
        success: false
      })
    }
  })
})

router.get('/getAllBookings', (req, res) => {
  console.log("all")
  Bookings.find((err, docs) => {
    if (!err) {
      res.send(docs)
    }
    else {
      res.send(err)
    }
  })
})

router.post('/deletAll', (req, res) => {
  User.findOneAndDelete({ user_phone: req.body.user_phone }, (err, docs) => {
    if (!err) {
      console.log("User Deleted")
    }
    else { console.log(err) }
  })

  Bookings.findOneAndDelete({ user_phone: req.body.user_phone }, (err, docs) => {
    if (!err) {
      console.log("Booking Deleted")
    }
    else { console.log(err) }
  })

  res.send('deleted')
})

router.post('/clearAdminBookings', (req, res) => {
  adminBookings.findByIdAndDelete({ _id: req.body.id }, (err, docs) => {
    if (!err) {
      res.send("delete")
    }
  })
})

module.exports = router;
