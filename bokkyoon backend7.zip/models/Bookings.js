const { Schema, model } = require("mongoose");

const Bookings = new Schema(
  {
    user_phone:{
      type: Number,
      required: true
    },
    email: {
      type: String,
    },
    user_name: {
      type: String,
    },
    bookings:[{
      driver_name:{type:String,default: ''},
      driver_image:{type:String,default: ''},
      driver_phone:{type:String,default: ''},
      vehicle_name:{type:String,default: ''},
      Vehicle_Registration_Number:{type:String,default: ''},
      Vehicle_Image:{type:String,default: ''},
      Vehicle_type:{type:String,default: ''},
      source:{type:String,default: ''},
      destination:{type:String,default: ''},
      fare:{type:String,default: ''},
      date:{type: Date, required: true, default: Date.now()},
      status:{type:Number,require:true,default:1}
      
    }]
  },
  { timestamps: true }
);

module.exports = model("Bookings", Bookings);
